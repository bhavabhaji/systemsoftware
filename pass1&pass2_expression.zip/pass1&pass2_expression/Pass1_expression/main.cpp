#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <unordered_map>
#include <vector>
#include <algorithm> // Include this header for std::find

using namespace std;

struct Symbol {
    string label;
    int address;
    bool isDefined;
    char type; // 'R' for relative, 'A' for absolute

    Symbol() : label(""), address(0), isDefined(false), type('R') {}
    Symbol(string l, int addr, bool def = false, char t = 'R') : label(l), address(addr), isDefined(def), type(t) {}
};

unordered_map<string, Symbol> symbolTable;
vector<string> labels;

void passOne() {
    string label, opcode, operand, mnemonic, line;
    int start = 0, locctr = 0;
    ifstream input("pass1_input_code.txt"), optab("pass1_optab.txt");
    ofstream symtab("pass1_symtab.txt"), symtabType("pass1_symtab_type.txt"), intermediate("pass1_intermediate_code.txt");

    if (!input || !optab || !symtab || !symtabType || !intermediate) {
        cerr << "Error: Could not open one or more files." << endl;
        exit(1);
    }

    getline(input, line);
    stringstream firstLine(line);
    firstLine >> label >> opcode >> operand;

    if (opcode == "START") {
        start = stoi(operand, nullptr, 16);
        locctr = start;
        intermediate << hex << uppercase << setw(4) << setfill('0') << locctr << "\t"
                     << label << "\t" << opcode << "\t" << operand << endl;
        cout << hex << uppercase << setw(4) << setfill('0') << locctr << "\t"
             << label << "\t" << opcode << "\t" << operand << endl;
    }

    while (getline(input, line)) {
        stringstream ss(line);
        ss >> label >> opcode >> operand;

        if (opcode == "EQU") {
            int value = 0;
            char type = 'R';
            if (operand.find('+') != string::npos) {
                string op1 = operand.substr(0, operand.find('+'));
                string op2 = operand.substr(operand.find('+') + 1);
                value = symbolTable[op1].address + stoi(op2, nullptr, 16);
            } else if (operand.find('-') != string::npos) {
                string op1 = operand.substr(0, operand.find('-'));
                string op2 = operand.substr(operand.find('-') + 1);
                value = symbolTable[op1].address - symbolTable[op2].address;
                type = 'A'; // If we perform subtraction, it is absolute
            } else if (symbolTable.find(operand) != symbolTable.end()) {
                value = symbolTable[operand].address;
            } else {
                value = stoi(operand, nullptr, 16);
                type = 'A';
            }
            symbolTable[label] = Symbol(label, value, true, type);
            intermediate << hex << uppercase << setw(4) << setfill('0') << value << "\t"
                         << label << "\t" << opcode << "\t" << operand << endl;
            if (find(labels.begin(), labels.end(), label) == labels.end()) {
                labels.push_back(label);
            }
            continue;  // Skip updating locctr for EQU
        }

        if (!label.empty() && label != "-") {
            if (symbolTable.find(label) == symbolTable.end()) {
                symbolTable[label] = Symbol(label, locctr);
                labels.push_back(label);
            }
        }

        intermediate << hex << uppercase << setw(4) << setfill('0') << locctr << "\t"
                     << label << "\t" << opcode << "\t" << operand << endl;
        cout << hex << uppercase << setw(4) << setfill('0') << locctr << "\t"
             << label << "\t" << opcode << "\t" << operand << endl;

        int format = 3;
        if (opcode[0] == '+') {
            format = 4;
            opcode = opcode.substr(1);
        }

        bool found = false;
        optab.clear();
        optab.seekg(0, ios::beg);
        while (getline(optab, line)) {
            stringstream optabLine(line);
            optabLine >> mnemonic;
            if (opcode == mnemonic) {
                found = true;
                break;
            }
        }

        if (found) {
            if (opcode == "CLEAR" || opcode == "TIXR" || opcode == "ADDR" ||
                opcode == "SUBR" || opcode == "MULR" || opcode == "DIVR" ||
                opcode == "COMPR" || opcode == "SHIFTL" || opcode == "SHIFTR" ||
                opcode == "SVC" || (opcode.back() == 'R' && opcode.size() <= 5)) {
                format = 2;
            } else if (operand == "-") {
                format = 1;
            }

            locctr += (format == 1) ? 1 : (format == 2) ? 2 : (format == 4) ? 4 : 3;
        } else if (opcode == "WORD") {
            locctr += 3;
        } else if (opcode == "RESW") {
            locctr += 3 * stoi(operand);
        } else if (opcode == "RESB") {
            locctr += stoi(operand);
        } else if (opcode == "BYTE") {
            if (operand[0] == 'C') {
                locctr += operand.length() - 3;
            } else if (operand[0] == 'X') {
                locctr += (operand.length() - 3) / 2;
            }
        }

        if (opcode == "END") {
            break;
        }
    }

    // Write the symbol table to the file without type
    for (const auto& label : labels) {
        symtab << label << "\t" << hex << uppercase << setw(4) << setfill('0') << symbolTable[label].address << endl;
    }

    // Write the symbol table to the file with type
    for (const auto& label : labels) {
        symtabType << label << "\t" << hex << uppercase << setw(4) << setfill('0') << symbolTable[label].address
                   << "\t" << symbolTable[label].type << endl;
    }

    input.close();
    optab.close();
    symtab.close();
    symtabType.close();
    intermediate.close();

    int length = locctr - start;
    cout << "Length of the program is " << hex << uppercase << setw(4) << setfill('0') << length << endl;
    cout << "Pass 1 completed successfully for SIC-XE." << endl;
}

void printSymbolTable() {
    cout << "Symbol Table:" << endl;
    for (const auto& symbol : symbolTable) {
        cout << "Label: " << symbol.first << "\tAddress: " << hex << uppercase << setw(4) << setfill('0') << symbol.second.address
             << "\tType: " << symbol.second.type << endl;
    }
}

int main() {
    passOne();
    printSymbolTable();
    return 0;
}
