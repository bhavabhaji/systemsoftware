#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

char *decimalToHex(int decimal) {
    static char hex_string[20];
    sprintf(hex_string, "%X", decimal);
    return hex_string;
}

void passTwo() {
    char label[10], opcode[10], operand[10], mnemonic[10], symbol[10];
    int locctr, start = 0, operandAddress = 0, baseAddress = 0;
    int programLength = 0, endAddress = 0;
    char line[100], textRecord[70] = "", objectCode[10], tempObjectCode[10];
    FILE *intermediate, *optab, *symtab, *objectProgram, *objcodeFile;

    // Open required files
    intermediate = fopen("E:/Coding/Pass1_expression/cmake-build-debug/pass1_intermediate_code.txt", "r");
    optab = fopen("E:/Coding/Pass1_expression/cmake-build-debug/pass1_optab.txt", "r");
    symtab = fopen("E:/Coding/Pass1_expression/cmake-build-debug/pass1_symtab.txt", "r");
    objectProgram = fopen("pass2_object_program.txt", "w");
    objcodeFile = fopen("pass2_object_code.txt", "w");

    if (!intermediate || !optab || !symtab || !objectProgram || !objcodeFile) {
        printf("Error: Could not open one or more files.\n");
        exit(1);
    }

    // Read first line of intermediate file
    fgets(line, sizeof(line), intermediate);
    sscanf(line, "%X %s %s %s", &locctr, label, opcode, operand);

    // Check if opcode is "START"
    if (strcmp(opcode, "START") == 0) {
        start = (int)strtol(operand, NULL, 16);
        fprintf(objectProgram, "H^%-6s^%06X^      \n", label, start);  // Write initial part of the header record
        fgets(line, sizeof(line), intermediate);
    }

    printf("Loc   Label    Opcode   Operand  ObjectCode\n");
    printf("-------------------------------------------\n");

    // Start text record and text record tracking variables
    int textRecordStart = start;
    int textRecordLength = 0;

    // Process each line in the intermediate file
    while (strcmp(opcode, "END") != 0) {
        sscanf(line, "%X %s %s %s", &locctr, label, opcode, operand);
        rewind(optab);
        int found = 0;

        // Search OPTAB for opcode
        while (fgets(line, sizeof(line), optab) != NULL) {
            sscanf(line, "%s %s", mnemonic, tempObjectCode);
            if (strcmp(opcode[0] == '+' ? opcode + 1 : opcode, mnemonic) == 0) {
                found = 1;
                break;
            }
        }

        if (found) {
            int format = (opcode[0] == '+') ? 4 : 3;
            operandAddress = 0;
            int n = 1, i = 1, x = 0, b = 0, p = 0, e = 0;

            if (operand[0] == '#') {  // Immediate addressing
                n = 0;
                i = 1;
                operandAddress = strtol(operand + 1, NULL, 10);
                if (operandAddress <= 4095) {
                    // Immediate values directly used if <= 12 bits
                    sprintf(objectCode, "%02X%04X", (int)strtol(tempObjectCode, NULL, 16) + (n << 1) + i, operandAddress);
                }
            } else if (operand[0] == '@') {  // Indirect addressing
                i = 0;
                rewind(symtab);
                while (fgets(line, sizeof(line), symtab) != NULL) {
                    sscanf(line, "%s %X", symbol, &operandAddress);
                    if (strcmp(symbol, operand + 1) == 0) break;
                }
            } else {  // Simple addressing
                char baseOperand[10];
                if (strchr(operand, ',') != NULL) {  // Indexed addressing
                    sscanf(operand, "%[^,]", baseOperand);
                    x = 1;
                } else {
                    strcpy(baseOperand, operand);
                }

                rewind(symtab);
                while (fgets(line, sizeof(line), symtab) != NULL) {
                    sscanf(line, "%s %X", symbol, &operandAddress);
                    if (strcmp(symbol, baseOperand) == 0) break;
                }
            }

            // Handle PC-relative or Base-relative addressing
            if (format == 3) {
                int disp = operandAddress - (locctr + 3);
                if (disp >= -2048 && disp <= 2047) {
                    p = 1;
                    operandAddress = disp & 0xFFF;  // Mask to 12 bits
                } else if (baseAddress != 0 && operandAddress - baseAddress >= 0 && operandAddress - baseAddress <= 4095) {
                    b = 1;
                    operandAddress = (operandAddress - baseAddress) & 0xFFF;
                } else {
                    operandAddress = 0;
                }
            } else if (format == 4) {
                e = 1;
            }

            // Generate object code if not immediate addressing
            if (format == 3 && operand[0] != '#') {
                int opcodeValue = (int)strtol(tempObjectCode, NULL, 16);
                sprintf(objectCode, "%02X%01X%03X", opcodeValue + (n << 1) + i, x * 8 + b * 4 + p * 2 + e, operandAddress);
            } else if (format == 4) {
                int opcodeValue = (int)strtol(tempObjectCode, NULL, 16);
                sprintf(objectCode, "%02X%01X%05X", opcodeValue + (n << 1) + i, x * 8 + b * 4 + p * 2 + e, operandAddress);
            }

            // Write individual object code to OBJ_CODE.txt
            fprintf(objcodeFile, "%04X\t%-8s\t%-8s\t%-8s\t%s\n", locctr, label, opcode, operand, objectCode);

            // Append object code to text record
            if (strlen(textRecord) + strlen(objectCode) > 60) {
                fprintf(objectProgram, "T^%06X^%02X^%s\n", textRecordStart, textRecordLength, textRecord);
                strcpy(textRecord, "");  // Reset text record
                textRecordStart = locctr;
                textRecordLength = 0;
            }
            strcat(textRecord, objectCode);
            textRecordLength += (format == 4 ? 4 : 3);

            // Display on terminal
            printf("%04X  %-8s%-8s%-8s%s\n", locctr, label, opcode, operand, objectCode);
        }

        endAddress = locctr;
        fgets(line, sizeof(line), intermediate);
    }

    // Write last Text record and End record
    if (strlen(textRecord) > 0) {
        fprintf(objectProgram, "T^%06X^%02X^%s\n", textRecordStart, textRecordLength, textRecord);
    }
    fprintf(objectProgram, "E^%06X\n", start);

    // Calculate and write program length in header record
    programLength = endAddress - start;
    fseek(objectProgram, 16, SEEK_SET);  // Move to header length field position
    fprintf(objectProgram, "%06X\n", programLength);

    fclose(intermediate);
    fclose(optab);
    fclose(symtab);
    fclose(objectProgram);
    fclose(objcodeFile);

    printf("-------------------------------------------\n");
    printf("Pass 2 completed successfully for SIC/XE.\n");
}

int main() {
    passTwo();
    return 0;
}
